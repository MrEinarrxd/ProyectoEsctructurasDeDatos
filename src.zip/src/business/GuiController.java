package business;

import domain.List.VehicleList;
import domain.List.StringList;
import domain.List.ServiceList;
import domain.List.RequestQueue;
import domain.Service;
import domain.Request;
import domain.Graphs.Graph;

public class GuiController {
    private final RequestController requestController;

    public GuiController(RequestController requestController) {
        this.requestController = requestController;
    }

    /**
     * Obtiene el mapa (grafo) del sistema de rutas.
     */
    public Graph getMap() {
        return requestController.getMap();
    }

    /**
     * Registra una nueva solicitud de transporte.
     */
    public Request registerRequest(String client, String origin, String destination, int priority) {
        return requestController.registerRequest(client, origin, destination, priority);
    }
    
    /**
     * Registra una nueva solicitud con categoría específica.
     */
    public Request registerRequest(String client, String origin, String destination, int priority, int category) {
        return requestController.registerRequest(client, origin, destination, priority, category);
    }

    /**
     * Procesa el siguiente servicio de la cola.
     */
    public Service processNextService() {
        return requestController.processNextService();
    }

    /**
     * Obtiene lista de vehículos ordenada por QuickSort.
     */
    public VehicleList getSortedVehiclesQuickSort() {
        return requestController.getSortedVehiclesQuickSort();
    }
    
    /**
     * Explora el mapa usando BFS desde un nodo inicial.
     */
    public String exploreMapBFS(String start) {
        return requestController.exploreMapBFS(start);
    }
    
    /**
     * Obtiene un reporte detallado de las colas de servicios.
     */
    public String getQueuesReport() {
        RequestQueue urgentQueue = requestController.getUrgentQueue();
        RequestQueue normalQueue = requestController.getNormalQueue();
        String result = "";

        result += "=== COLA DE SERVICIOS (PROCESADAS POR ÁRBOL DE TARIFAS) ===\n\n";

        result += "[EMERGENCIA] COLA URGENTE (Categoría: Emergencia):\n";
        result += "Tamaño: " + urgentQueue.getSize() + "\n";
        if (urgentQueue.isEmpty()) {
            result += "  [Vacía]\n";
        } else {
            int index = 1;
            for (int i = 0; i < urgentQueue.getSize(); i++) {
                Request req = urgentQueue.get(i);
                result += "  " + index++ + ". ";
                result += "ID: " + req.getId();
                result += " | Cliente: " + req.getClientName();
                result += " | Ruta: " + req.getOrigin() + " -> " + req.getDestination();
                result += " | Categoría: Emergencia";
                result += "\n";
            }
        }

        result += "\n";

        result += "[NORMAL] COLA NORMAL (Procesadas por: VIP > Regular > Económico):\n";
        result += "Tamaño: " + normalQueue.getSize() + "\n";
        if (normalQueue.isEmpty()) {
            result += "  [Vacía]\n";
        } else {
            int index = 1;
            for (int i = 0; i < normalQueue.getSize(); i++) {
                Request req = normalQueue.get(i);
                String category = getCategoryName(req.getClientCategory());
                result += "  " + index++ + ". ";
                result += "ID: " + req.getId();
                result += " | Cliente: " + req.getClientName();
                result += " | Ruta: " + req.getOrigin() + " -> " + req.getDestination();
                result += " | Categoría: " + category;
                result += "\n";
            }
        }

        result += "\nTotal de solicitudes pendientes: " + (urgentQueue.getSize() + normalQueue.getSize()) + "\n";

        return result;
    }

    /**
     * Obtiene la lista de servicios completados.
     */
    public ServiceList getCompletedServices() {
        return requestController.getCompletedServices();
    }
    
    /**
     * Obtiene los nodos disponibles en el mapa.
     */
    public StringList getAvailableNodes() {
        return requestController.getAvailableNodes();
    }
    
    /**
     * Obtiene el nombre legible de la categoría de solicitud.
     */
    private String getCategoryName(int category) {
        switch(category) {
            case 0: return "Económico";
            case 1: return "Regular";
            case 2: return "VIP";
            case 3: return "Emergencia";
            default: return "Desconocido";
        }
    }
    
    /**
     * Guarda todos los datos del sistema a archivos de persistencia.
     */
    public void saveData() {
        requestController.saveData();
    }
    
    /**
     * Carga todos los datos del sistema desde archivos de persistencia.
     */
    public void loadData() {
        requestController.loadData();
    }
}
