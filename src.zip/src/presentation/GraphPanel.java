package presentation;

import java.awt.*;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.HashMap;
import java.util.HashSet;

import javax.swing.*;

import domain.Graphs.Edge;
import domain.Graphs.Graph;

public class GraphPanel extends JPanel {
    // Constantes de layout
    private static final int PANEL_WIDTH = 900;
    private static final int PANEL_HEIGHT = 600;
    private static final int CENTER_X = PANEL_WIDTH / 2;
    private static final int CENTER_Y = PANEL_HEIGHT / 2;
    private static final int LAYOUT_RADIUS = 350;
    private static final int FORCE_ITERATIONS = 100;
    private static final double REPULSION_CONSTANT = 200.0;
    private static final double DAMPING_FACTOR = 0.05;
    private static final int NODE_RADIUS = 35;
    private static final int EDGE_LABEL_OFFSET = 15;
    private static final int MIN_POSITION = 50;
    private static final int MAX_POSITION_X = 850;
    private static final int MAX_POSITION_Y = 550;

    private Map<String, Point> posiciones;
    private Map<String, List<Edge>> edgeMap;

    public GraphPanel(Graph grafo) {
        this.posiciones = new HashMap<>();
        this.edgeMap = grafo.getEdgeMap();
        calculatePositions();
        setPreferredSize(new Dimension(PANEL_WIDTH, PANEL_HEIGHT));
    }

    /**
     * Calcula las posiciones de los nodos usando un algoritmo de fuerzas.
     * Intenta separar nodos repulsivos e integrar nodos conectados.
     */
    private void calculatePositions() {
        // Si no hay nodos, no hacer nada
        if (edgeMap.isEmpty()) {
            return;
        }
        
        // Obtener todos los nodos únicos
        Set<String> nodes = new HashSet<>();
        for (String node : edgeMap.keySet()) {
            nodes.add(node);
            for (Edge edge : edgeMap.get(node)) {
                nodes.add(edge.getTo());
            }
        }
        
        // Inicializar posiciones en círculo
        int totalNodes = nodes.size();
        int index = 0;
        for (String node : nodes) {
            double angle = (2 * Math.PI * index) / totalNodes;
            int x = CENTER_X + (int) (LAYOUT_RADIUS * Math.cos(angle));
            int y = CENTER_Y + (int) (LAYOUT_RADIUS * Math.sin(angle));
            posiciones.put(node, new Point(x, y));
            index++;
        }
        
        // Aplicar algoritmo force-directed (spring layout)
        applyForceDirectedLayout(nodes);
    }
    
    /**
     * Implementa layout dirigido por fuerzas (Force-Directed Layout).
     * Calcula posiciones iterativamente simulando repulsión entre nodos e
     * atracción entre nodos conectados, resultando en un layout legible.
     */
    private void applyForceDirectedLayout(Set<String> nodes) {
        Map<String, double[]> velocities = new HashMap<>();
        Map<String, double[]> forces = new HashMap<>();
        
        // Inicializar velocidades en cero
        for (String node : nodes) {
            velocities.put(node, new double[]{0, 0});
        }
        
        for (int iter = 0; iter < FORCE_ITERATIONS; iter++) {
            // Reinicializar fuerzas
            for (String node : nodes) {
                forces.put(node, new double[]{0, 0});
            }
            
            // Repulsión entre nodos
            applyRepulsion(nodes, forces);
            
            // Atracción por aristas (muelles)
            applyAttraction(forces);
            
            // Actualizar posiciones
            updatePositions(nodes, velocities, forces);
        }
    }

    /**
     * Calcula fuerzas repulsivas entre todos los pares de nodos.
     * Impide que los nodos se superpongan y evita aglomeración.
     */
    private void applyRepulsion(Set<String> nodes, Map<String, double[]> forces) {
        String[] nodesArray = nodes.toArray(new String[0]);
        for (int i = 0; i < nodesArray.length; i++) {
            for (int j = i + 1; j < nodesArray.length; j++) {
                String n1 = nodesArray[i];
                String n2 = nodesArray[j];
                
                Point p1 = posiciones.get(n1);
                Point p2 = posiciones.get(n2);
                
                double dx = p2.x - p1.x;
                double dy = p2.y - p1.y;
                double dist = Math.sqrt(dx * dx + dy * dy);
                
                if (dist > 1) {
                    double force = REPULSION_CONSTANT / dist;
                    double fx = (dx / dist) * force;
                    double fy = (dy / dist) * force;
                    
                    forces.get(n1)[0] -= fx;
                    forces.get(n1)[1] -= fy;
                    forces.get(n2)[0] += fx;
                    forces.get(n2)[1] += fy;
                }
            }
        }
    }

    /**
     * Calcula fuerzas atractivas entre nodos conectados (como muelles).
     * Reduce la distancia entre nodos vecinos para mejorar legibilidad.
     */
    private void applyAttraction(Map<String, double[]> forces) {
        double restLength = 300;
        for (String origin : edgeMap.keySet()) {
            for (Edge edge : edgeMap.get(origin)) {
                String destination = edge.getTo();
                if (posiciones.containsKey(destination)) {
                    Point p1 = posiciones.get(origin);
                    Point p2 = posiciones.get(destination);
                    
                    double dx = p2.x - p1.x;
                    double dy = p2.y - p1.y;
                    double dist = Math.sqrt(dx * dx + dy * dy);
                    
                    if (dist > 0.1) {
                        double force = 0.01 * (dist - restLength);
                        double fx = (dx / dist) * force;
                        double fy = (dy / dist) * force;
                        
                        forces.get(origin)[0] += fx;
                        forces.get(origin)[1] += fy;
                        forces.get(destination)[0] -= fx;
                        forces.get(destination)[1] -= fy;
                    }
                }
            }
        }
    }

    /**
     * Actualiza las posiciones de los nodos basado en velocidades y fuerzas.
     * Aplica amortiguamiento para evitar oscilación excesiva.
     */
    private void updatePositions(Set<String> nodes, Map<String, double[]> velocities, Map<String, double[]> forces) {
        for (String node : nodes) {
            double[] vel = velocities.get(node);
            double[] force = forces.get(node);
            Point pos = posiciones.get(node);
            
            vel[0] = (vel[0] + force[0]) * (1 - DAMPING_FACTOR);
            vel[1] = (vel[1] + force[1]) * (1 - DAMPING_FACTOR);
            
            int newX = Math.max(MIN_POSITION, Math.min(MAX_POSITION_X, (int)(pos.x + vel[0])));
            int newY = Math.max(MIN_POSITION, Math.min(MAX_POSITION_Y, (int)(pos.y + vel[1])));
            
            posiciones.put(node, new Point(newX, newY));
        }
    }

    /**
     * Obtiene el peso máximo de todas las aristas para normalización.
     */
    private int getMaxWeight() {
        int max = 1;
        for (List<Edge> edges : edgeMap.values()) {
            for (Edge edge : edges) {
                max = Math.max(max, edge.getWeight());
            }
        }
        return max;
    }

    /**
     * Crea una clave única bidireccional para una arista (A-B es lo mismo que B-A).
     */
    private String createEdgeKey(String n1, String n2) {
        return n1.compareTo(n2) < 0 ? n1 + "||" + n2 : n2 + "||" + n1;
    }

    /**
     * Dibuja el grafo con sus nodos, aristas y etiquetas de peso.
     * Utiliza colores para representar pesos (gradiente de colors).
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                           RenderingHints.VALUE_ANTIALIAS_ON);

        Set<String> drawnEdges = new HashSet<>();
        Map<String, Integer> distances = new HashMap<>();
        int maxWeight = getMaxWeight();

        // Dibujar aristas con colores según peso
        for (String origin : edgeMap.keySet()) {
            Point p1 = posiciones.get(origin);
            if (p1 == null) continue;

            for (Edge edge : edgeMap.get(origin)) {
                Point p2 = posiciones.get(edge.getTo());
                if (p2 == null) continue;

                String key = createEdgeKey(origin, edge.getTo());
                
                if (drawnEdges.contains(key)) continue;
                drawnEdges.add(key);
                distances.put(key, edge.getWeight());

                // Calcular color según peso (gradiente: azul->cian->verde->amarillo->naranja->rojo)
                float ratio = (float) edge.getWeight() / maxWeight;
                Color color = getColorByWeight(ratio);
                g2d.setColor(color);
                g2d.setStroke(new BasicStroke(2 + (int)(ratio * 3))); // Grosor aumenta con peso
                g2d.drawLine(p1.x, p1.y, p2.x, p2.y);
            }
        }

        // Dibujar etiquetas de distancias con fondo blanco
        for (Map.Entry<String, Integer> entry : distances.entrySet()) {
            String key = entry.getKey();
            String[] parts = key.split("\\|\\|");
            if (parts.length == 2) {
                Point p1 = posiciones.get(parts[0]);
                Point p2 = posiciones.get(parts[1]);
                
                if (p1 != null && p2 != null) {
                    int midX = (p1.x + p2.x) / 2;
                    int midY = (p1.y + p2.y) / 2;
                    
                    int dx = p2.x - p1.x;
                    int dy = p2.y - p1.y;
                    int length = (int) Math.sqrt(dx * dx + dy * dy);
                    
                    int perpX = 0, perpY = 0;
                    if (length > 0) {
                        perpX = (-dy * EDGE_LABEL_OFFSET) / length;
                        perpY = (dx * EDGE_LABEL_OFFSET) / length;
                    }
                    
                    // Fondo blanco para el texto
                    g2d.setColor(new Color(255, 255, 255, 220));
                    String text = String.valueOf(entry.getValue());
                    FontMetrics fm = g2d.getFontMetrics();
                    int textWidth = fm.stringWidth(text);
                    int textHeight = fm.getAscent();
                    
                    g2d.fillRect(midX + perpX - textWidth/2 - 3, midY + perpY - textHeight - 2, 
                                textWidth + 6, textHeight + 4);
                    
                    // Texto con color de la arista
                    float ratio = (float) entry.getValue() / maxWeight;
                    Color edgeColor = getColorByWeight(ratio);
                    g2d.setColor(edgeColor);
                    g2d.setFont(new Font("Arial", Font.BOLD, 13));
                    g2d.drawString(text, midX + perpX - textWidth/2, midY + perpY);
                }
            }
        }

        // Dibujar nodos
        for (Map.Entry<String, Point> entry : posiciones.entrySet()) {
            Point p = entry.getValue();
            g2d.setColor(Color.BLUE);
            g2d.fillOval(p.x - NODE_RADIUS, p.y - NODE_RADIUS, NODE_RADIUS * 2, NODE_RADIUS * 2);
            g2d.setColor(Color.WHITE);
            g2d.setStroke(new BasicStroke(2));
            g2d.drawOval(p.x - NODE_RADIUS, p.y - NODE_RADIUS, NODE_RADIUS * 2, NODE_RADIUS * 2);
            
            String name = entry.getKey();
            FontMetrics fm = g2d.getFontMetrics();
            int textWidth = fm.stringWidth(name);
            int textHeight = fm.getAscent();
            
            g2d.setColor(Color.WHITE);
            g2d.setFont(new Font("Arial", Font.BOLD, 12));
            g2d.drawString(name, p.x - textWidth / 2, p.y + textHeight / 4);
        }
    }

    /**
     * Obtiene un color basado en un ratio (0.0 a 1.0).
     * Paleta: Azul profundo -> Cian -> Verde -> Amarillo -> Naranja -> Rojo
     */
    private Color getColorByWeight(float ratio) {
        // Paleta de colores estética: Azul profundo -> Cian -> Verde -> Amarillo -> Naranja -> Rojo
        if (ratio < 0.2f) {
            // Azul profundo a Cian
            float localRatio = ratio / 0.2f;
            int r = (int) (0 + 0 * localRatio);
            int g = (int) (102 + 153 * localRatio);
            int b = (int) (204 + 51 * localRatio);
            return new Color(r, g, b);
        } else if (ratio < 0.4f) {
            // Cian a Verde
            float localRatio = (ratio - 0.2f) / 0.2f;
            int r = (int) (0 + 0 * localRatio);
            int g = (int) (255 - 55 * localRatio);
            int b = (int) (255 - 155 * localRatio);
            return new Color(r, g, b);
        } else if (ratio < 0.6f) {
            // Verde a Amarillo
            float localRatio = (ratio - 0.4f) / 0.2f;
            int r = (int) (0 + 255 * localRatio);
            int g = (int) (200 + 55 * localRatio);
            int b = (int) (100 - 100 * localRatio);
            return new Color(r, g, b);
        } else if (ratio < 0.8f) {
            // Amarillo a Naranja
            float localRatio = (ratio - 0.6f) / 0.2f;
            int r = (int) (255 + 0 * localRatio);
            int g = (int) (255 - 155 * localRatio);
            int b = (int) (0);
            return new Color(r, g, b);
        } else {
            // Naranja a Rojo oscuro
            float localRatio = (ratio - 0.8f) / 0.2f;
            int r = (int) (255 - 55 * localRatio);
            int g = (int) (100 - 100 * localRatio);
            int b = (int) (0);
            return new Color(r, g, b);
        }
    }
}
