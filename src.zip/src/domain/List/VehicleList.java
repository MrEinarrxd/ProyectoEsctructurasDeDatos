package domain.List;

import domain.Vehicle;
import java.util.ArrayList;
import java.util.List;

public class VehicleList extends BaseLinkedList {

    /**
     * Añade un vehículo a la lista.
     * Inserta al final de la lista (O(n))
     */
    public void add(Vehicle vehicle) {
        VehicleNode newNode = new VehicleNode(vehicle);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
        size++;
    }

    /**
     * Obtiene el vehículo en el índice especificado.
     */
    public Vehicle get(int index) {
        Object obj = super.get(index);
        return (Vehicle) obj;
    }

    /**
     * Verifica si un vehículo existe en la lista.
     */
    public boolean contains(Vehicle vehicle) {
        return super.contains(vehicle);
    }

    /**
     * Obtiene todos los vehículos como una lista de ArrayList.
     * Útil para iteración y paso a métodos que esperan List<Vehicle>
     */
    public List<Vehicle> getAll() {
        List<Vehicle> list = new ArrayList<>();
        Node current = head;
        while (current != null) {
            VehicleNode vehicleNode = (VehicleNode) current;
            list.add(vehicleNode.getVehicle());
            current = current.next;
        }
        return list;
    }
    
    /**
     * Busca un vehículo disponible en la zona especificada.
     * Retorna el primer vehículo disponible encontrado o null si no existe.
     */
    public Vehicle findAvailable(String zone) {
        Node current = head;
        while (current != null) {
            VehicleNode vehicleNode = (VehicleNode) current;
            Vehicle v = vehicleNode.getVehicle();
            if (v.isAvailable() && v.getCurrentZone().equals(zone)) {
                return v;
            }
            current = current.next;
        }
        return null;
    }

    /**
     * Representación en string de la lista de vehículos.
     */
    @Override
    public String toString() {
        if (isEmpty()) {
            return "Lista vacía";
        }
        
        String result = "";
        Node current = head;
        while (current != null) {
            VehicleNode vehicleNode = (VehicleNode) current;
            result += vehicleNode.getVehicle().toString() + "\n";
            current = current.next;
        }
        return result;
    }
}
