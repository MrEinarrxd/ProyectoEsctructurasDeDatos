package domain.Graphs;

import domain.List.StringList;

public class Path {
    public int distance;
    public StringList path;
    
    /**
     * Información adicional para resultados detallados del algoritmo.
     * Estos campos se populan por métodos como calculateDijkstraRoute
     */
    public StringList pathDetail;
    public int totalDistance;
    public String algorithmDetail;
    
    /**
     * Constructor estándar con distancia y ruta.
     */
    public Path(int distance, StringList path) {
        this.distance = distance;
        this.path = path;
        this.pathDetail = new StringList();
        this.totalDistance = distance;
        this.algorithmDetail = "";
        
        // Copiar el camino original al nuevo campo para detalles
        for (int i = 0; i < path.getSize(); i++) {
            this.pathDetail.add(path.get(i));
        }
    }
    
    /**
     * Constructor vacío para resultados sin ruta.
     */
    public Path() {
        this.distance = 0;
        this.path = new StringList();
        this.pathDetail = new StringList();
        this.totalDistance = 0;
        this.algorithmDetail = "";
    }
    
    @Override
    public String toString() {
        if (distance < 0) {
            return "No hay ruta disponible";
        }
        
        String result = "Distancia: " + distance + " | Ruta: ";
        
        for (int i = 0; i < path.getSize(); i++) {
            result += path.get(i);
            if (i < path.getSize() - 1) {
                result += " -> ";
            }
        }
        
        return result;
    }
}
