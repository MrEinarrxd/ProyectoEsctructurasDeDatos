package domain.Graphs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import domain.Vehicle;
import domain.List.EdgeList;
import domain.List.GraphNodeList;
import domain.List.StringList;

public class Graph {
    private GraphNodeList nodes;
    
    public Graph() {
        this.nodes = new GraphNodeList();
    }
    
    public void addNode(String name) {
        if (!hasNode(name)) {
            GraphNode newNode = new GraphNode(name);
            nodes.add(newNode);
        }
    }
    
    public void addEdge(String from, String to) {
        addEdge(from, to, 1);
    }
    
    public void addEdge(String from, String to, int weight) {
        addNode(from);
        addNode(to);
        
        GraphNode fromNode = getNode(from);
        fromNode.addEdge(to, weight);
        
        GraphNode toNode = getNode(to);
        toNode.addEdge(from, weight);
    }
    
    public GraphNode getNode(String name) {
        for (int i = 0; i < nodes.getSize(); i++) {
            GraphNode node = nodes.get(i);
            if (node != null && node.getName().equals(name)) {
                return node;
            }
        }
        return null;
    }
    
    public boolean hasNode(String name) {
        return getNode(name) != null;
    }
    
    public void addVehicleToNode(String nodeName, Vehicle vehicle) {
        GraphNode node = getNode(nodeName);
        if (node != null) {
            node.addVehicle(vehicle);
        }
    }
    
    public int getNodeCount() {
        return nodes.getSize();
    }

    /**
     * Implementa Breadth-First Search (BFS) para explorar el grafo.
     * 
     * Proceso:
     *   1. Añade el nodo inicial a la cola
     *   2. Mientras haya nodos en la cola:
     *      a. Extrae el primer nodo (FIFO)
     *      b. Marca como visitado
     *      c. Añade todos los vecinos no visitados a la cola
     *   3. Retorna el orden de visitación
     * 
     * Complejidad: O(V + E) donde V=vértices, E=aristas
     * Útil para: Búsqueda de caminos más cortos, exploración por niveles
     */
    public String bfs(String start) {
        String result = "=== EXPLORACIÓN BFS (Breadth-First Search) ===\n";
        result += "Inicio: " + start + "\n\n";

        if (!hasNode(start)) {
            result += "Error: Nodo no encontrado\n";
            return result;
        }

        StringList queue = new StringList();
        StringList visited = new StringList();
        StringList traversal = new StringList();

        queue.add(start);
        visited.add(start);

        result += "Paso a paso:\n";
        int step = 1;
        int queueIndex = 0;

        while (queueIndex < queue.getSize()) {
            String current = queue.get(queueIndex);
            queueIndex++;
            traversal.add(current);

            result += step++ + ". Visitando: " + current + "\n";
            result += "   Vecinos: ";

            boolean hasNeighbors = false;
            GraphNode currentNode = getNode(current);
            if (currentNode != null) {
                String[] neighbors = currentNode.getNeighbors();
                for (String neighbor : neighbors) {
                    if (neighbor == null) continue;
                    hasNeighbors = true;
                    if (!visited.contains(neighbor)) {
                        queue.add(neighbor);
                        visited.add(neighbor);
                        result += neighbor + " (agregado) ";
                    } else {
                        result += neighbor + " (ya visitado) ";
                    }
                }
            }

            if (!hasNeighbors) {
                result += "ninguno";
            }
            result += "\n\n";
        }

        result += "Orden de recorrido completo: ";
        for (int i = 0; i < traversal.getSize(); i++) {
            result += traversal.get(i);
            if (i < traversal.getSize() - 1) result += " → ";
        }
        result += "\n";

        return result;
    }
    
    public Path shortestPath(String from, String to) {
        if (!hasNode(from) || !hasNode(to)) {
            return new Path(-1, new StringList());
        }
        if (from.equals(to)) {
            StringList path = new StringList();
            path.add(from);
            return new Path(0, path);
        }
        
        int total = nodes.getSize();
        StringList queue = new StringList();
        int headIndex = 0;
        boolean[] visited = new boolean[total];
        String[] previous = new String[total];
        int[] distance = new int[total];
        
        for (int i = 0; i < total; i++) {
            distance[i] = -1;
        }
        
        int fromIndex = getNodeIndex(from);
        visited[fromIndex] = true;
        distance[fromIndex] = 0;
        queue.add(from);
        
        while (headIndex < queue.getSize()) {
            String currentName = queue.get(headIndex);
            headIndex++;
            
            if (currentName.equals(to)) {
                StringList path = reconstructPath(previous, from, to);
                return new Path(distance[getNodeIndex(to)], path);
            }

            GraphNode currentNode = getNode(currentName);
            String[] neighbors = currentNode.getNeighbors();
            
            for (int i = 0; i < neighbors.length; i++) {
                String neighbor = neighbors[i];
                if (neighbor == null) continue;
                
                int neighborIndex = getNodeIndex(neighbor);
                if (!visited[neighborIndex]) {
                    visited[neighborIndex] = true;
                    previous[neighborIndex] = currentName;
                    distance[neighborIndex] = distance[getNodeIndex(currentName)] + 1;
                    queue.add(neighbor);
                }
            }
        }
        return new Path(-1, new StringList());
    }
    
    public Path dijkstra(String source, String target) {
        if (!hasNode(source) || !hasNode(target)) {
            return new Path(-1, new StringList());
        }
        if (source.equals(target)) {
            StringList path = new StringList();
            path.add(source);
            return new Path(0, path);
        }
        
        int total = nodes.getSize();
        int[] distance = new int[total];
        boolean[] visited = new boolean[total];
        String[] previous = new String[total];
        
        for (int i = 0; i < total; i++) {
            distance[i] = Integer.MAX_VALUE;
            visited[i] = false;
            previous[i] = null;
        }
        
        int sourceIndex = getNodeIndex(source);
        distance[sourceIndex] = 0;
        
        for (int count = 0; count < total - 1; count++) {
            int minDistance = Integer.MAX_VALUE;
            int minIndex = -1;
            
            for (int i = 0; i < total; i++) {
                if (!visited[i] && distance[i] < minDistance) {
                    minDistance = distance[i];
                    minIndex = i;
                }
            }
            
            if (minIndex == -1) break;
            
            visited[minIndex] = true;
            String currentName = getNode(minIndex).getName();
            
            GraphNode currentNode = getNode(currentName);
            EdgeList edges = currentNode.getEdges();
            
            for (int i = 0; i < edges.getSize(); i++) {
                Edge edge = (Edge) edges.get(i);
                if (edge != null) {
                    String neighborName = edge.getTo();
                    int neighborIndex = getNodeIndex(neighborName);
                    int weight = edge.getWeight();
                    
                    if (!visited[neighborIndex] && distance[minIndex] != Integer.MAX_VALUE && 
                        distance[minIndex] + weight < distance[neighborIndex]) {
                        distance[neighborIndex] = distance[minIndex] + weight;
                        previous[neighborIndex] = currentName;
                    }
                }
            }
        }
        
        int targetIndex = getNodeIndex(target);
        if (distance[targetIndex] == Integer.MAX_VALUE) {
            return new Path(-1, new StringList());
        }
        
        StringList path = new StringList();
        String current = target;
        while (current != null) {
            path.addFirst(current);
            if (current.equals(source)) break;
            current = previous[getNodeIndex(current)];
        }
        
        return new Path(distance[targetIndex], path);
    }

    /**
     * Implementa el algoritmo de Dijkstra para encontrar la ruta más corta.
     * 
     * Proceso:
     *   1. Inicializa distancias con ∞ (excepto el inicio en 0)
     *   2. Selecciona iterativamente el nodo no visitado con menor distancia
     *   3. Relaja los bordes adyacentes actualizando distancias si encuentra una ruta más corta
     *   4. Continúa hasta visitar todos los nodos o encontrar el destino
     * 
     * Complejidad: O(V²) donde V es el número de nodos
     */
    public Path calculateDijkstraRoute(String origin, String destination) {
        Path result = new Path();
        String detail = "";

        if (!hasNode(origin) || !hasNode(destination)) {
            result.algorithmDetail = "Nodo no encontrado en el mapa";
            return result;
        }

        detail += "═══════════════════════════════════════\n";
        detail += "     ALGORITMO DIJKSTRA - BÚSQUEDA DE RUTA ÓPTIMA\n";
        detail += "═══════════════════════════════════════\n\n";
        detail += "Origen: " + origin + "  →  Destino: " + destination + "\n\n";

        int total = nodes.getSize();
        int[] distance = new int[total];
        boolean[] visited = new boolean[total];
        String[] previous = new String[total];

        for (int i = 0; i < total; i++) {
            distance[i] = Integer.MAX_VALUE;
            visited[i] = false;
            previous[i] = null;
        }

        int originIndex = getNodeIndex(origin);
        distance[originIndex] = 0;

        detail += "PASO 1: Inicializar\n";
        detail += "────────────────────\n";
        detail += "  • Distancia[" + origin + "] = 0\n";
        detail += "  • Resto de nodos = ∞\n\n";

        detail += "PASO 2: Procesar nodos\n";
        detail += "────────────────────\n";
        
        int step = 1;
        for (int count = 0; count < total; count++) {
            int minDist = Integer.MAX_VALUE;
            int minIndex = -1;

            for (int i = 0; i < total; i++) {
                if (!visited[i] && distance[i] < minDist) {
                    minDist = distance[i];
                    minIndex = i;
                }
            }

            if (minIndex == -1) break;

            String currentNode = getNode(minIndex).getName();
            visited[minIndex] = true;

            detail += "  " + step++ + ". Nodo: " + currentNode + " (distancia: " + distance[minIndex] + ")\n";

            if (currentNode.equals(destination)) {
                detail += "     DESTINO ALCANZADO!\n\n";
                break;
            }

            GraphNode actualNode = getNode(currentNode);
            EdgeList edges = actualNode.getEdges();
            for (int i = 0; i < edges.getSize(); i++) {
                Edge edge = (Edge) edges.get(i);
                if (edge == null) continue;

                String neighbor = edge.getTo();
                int neighborIndex = getNodeIndex(neighbor);
                if (neighborIndex < 0 || visited[neighborIndex]) continue;

                int newDistance = distance[minIndex] + edge.getWeight();
                int currentDistance = distance[neighborIndex];

                if (newDistance < currentDistance) {
                    distance[neighborIndex] = newDistance;
                    previous[neighborIndex] = currentNode;
                }
            }
        }

        detail += "\nPASO 3: Reconstruir ruta\n";
        detail += "────────────────────\n";
        int destinationIndex = getNodeIndex(destination);
        if (destinationIndex >= 0 && distance[destinationIndex] != Integer.MAX_VALUE) {
            StringList path = new StringList();
            String current = destination;
            while (current != null) {
                path.addFirst(current);
                current = previous[getNodeIndex(current)];
            }

            result.path = path;
            result.totalDistance = distance[destinationIndex];

            detail += "  Ruta óptima: ";
            for (int i = 0; i < path.getSize(); i++) {
                detail += path.get(i);
                if (i < path.getSize() - 1) detail += " → ";
            }
            detail += "\n  Distancia total: " + result.totalDistance + " unidades\n";
            detail += "\n═══════════════════════════════════════\n";
        } else {
            detail += "  No se encontró un camino válido\n";
            detail += "═══════════════════════════════════════\n";
        }

        result.algorithmDetail = detail;
        return result;
    }

    /**
     * Obtiene el mapa de adyacencia del grafo.
     * Retorna un Map donde la clave es el nombre del nodo
     * y el valor es la lista de aristas (bordes) desde ese nodo.
     */
    public Map<String, List<Edge>> getEdgeMap() {
        Map<String, List<Edge>> map = new HashMap<>();
        for (int i = 0; i < nodes.getSize(); i++) {
            GraphNode node = nodes.get(i);
            if (node == null) continue;

            List<Edge> edges = new ArrayList<>();
            EdgeList edgeList = node.getEdges();
            for (int j = 0; j < edgeList.getSize(); j++) {
                Edge edge = (Edge) edgeList.get(j);
                if (edge != null) {
                    edges.add(new Edge(edge.getTo(), edge.getWeight()));
                }
            }
            map.put(node.getName(), edges);
        }
        return map;
    }
    
    public GraphNode getNode(int index) {
        if (index >= 0 && index < nodes.getSize()) {
            return nodes.get(index);
        }
        return null;
    }
    
    private int getNodeIndex(String name) {
        for (int i = 0; i < nodes.getSize(); i++) {
            GraphNode node = nodes.get(i);
            if (node != null && node.getName().equals(name)) {
                return i;
            }
        }
        return -1;
    }
    
    private StringList reconstructPath(String[] previous, String from, String to) {
        StringList path = new StringList();
        String current = to;
        
        while (current != null) {
            path.addFirst(current);
            if (current.equals(from)) break;
            current = previous[getNodeIndex(current)];
        }
        
        return path;
    }
    
    @Override
    public String toString() {
        String result = "Graph{\n";
        for (int i = 0; i < nodes.getSize(); i++) {
            GraphNode node = nodes.get(i);
            if (node != null) {
                result += "  " + node.getName() + " -> ";
                String[] neighbors = node.getNeighbors();
                for (int j = 0; j < neighbors.length; j++) {
                    if (neighbors[j] != null) {
                        result += neighbors[j] + " ";
                    }
                }
                result += "\n";
            }
        }
        result += "}";
        return result;
    }
}
