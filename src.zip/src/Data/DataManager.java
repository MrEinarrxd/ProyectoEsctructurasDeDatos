package Data;
import java.io.*;
import domain.*;
import domain.Graphs.Edge;
import domain.Graphs.Graph;
import domain.List.VehicleList;
import domain.List.StringList;

public class DataManager {
    
    /**
     * Obtiene el nombre legible de la categoría de solicitud.
     * 0: Económico, 1: Regular, 2: VIP, 3: Emergencia
     */
    private String getCategoryName(int category) {
        switch(category) {
            case 0: return "Económico";
            case 1: return "Regular";
            case 2: return "VIP";
            case 3: return "Emergencia";
            default: return "Desconocido";
        }
    }
    
    /**
     * Guarda la lista de vehículos en un archivo CSV.
     * Formato: ID,Zona,CantServicios,Disponible,Conductor,Tipo
     */
    public void saveVehicles(VehicleList vehicles, String file) {
        try (PrintWriter writer = new PrintWriter(file)) {
            for (Vehicle v : vehicles.getAll()) {
                writer.println(v.getId() + "," + v.getCurrentZone() + "," + v.getServiceCount() + "," + v.isAvailable() + "," + v.getDriverName() + "," + v.getVehicleType());
            }
        } catch (IOException e) {
            System.out.println("Error guardando vehículos: " + e.getMessage());
        }
    }

    /**
     * Carga vehículos desde un archivo CSV.
     * Reconstruye objetos Vehicle con todos sus atributos.
     */
    public VehicleList loadVehicles(String file) {
        VehicleList list = new VehicleList();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    String driverName = parts.length >= 5 ? parts[4] : "Driver";
                    String vehicleType = parts.length >= 6 ? parts[5] : "sedan";
                    Vehicle v = new Vehicle(parts[0], driverName, parts[1], vehicleType);
                    // Establecer serviceCount usando incrementServiceCount varias veces
                    int serviceCount = Integer.parseInt(parts[2]);
                    for (int i = 0; i < serviceCount; i++) {
                        v.incrementServiceCount();
                    }
                    if (parts.length >= 4) v.setAvailable(Boolean.parseBoolean(parts[3]));
                    list.add(v);
                }
            }
        } catch (IOException e) {
            System.out.println("Error cargando vehículos: " + e.getMessage());
        }
        return list;
    }
    
    /**
     * Guarda las solicitudes pendientes en un archivo CSV.
     * Formato: ID,Cliente,Origen,Destino,Categoría
     */
    public void saveRequests(domain.List.RequestQueue requests, String file) {
        try (PrintWriter writer = new PrintWriter(file)) {
            domain.List.RequestQueue queue = requests.getAll();
            for (int i = 0; i < queue.size(); i++) {
                Request r = queue.get(i);
                writer.println(r.getId() + "," + r.getClientName() + "," + r.getOrigin() + "," + r.getDestination() + "," + r.getClientCategory());
            }
        } catch (IOException e) {
            System.out.println("Error guardando solicitudes: " + e.getMessage());
        }
    }
    
    /**
     * Guarda los servicios completados en un archivo CSV.
     * Formato: ID,SolicitudID,VehículoID,Ruta,Costo
     */
    public void saveServices(domain.List.ServiceList services, String file) {
        try (PrintWriter writer = new PrintWriter(file)) {
            domain.List.ServiceList serviceList = services.getAll();
            for (int i = 0; i < serviceList.getSize(); i++) {
                Service s = serviceList.get(i);
                writer.println(s.id + "," + s.request.getId() + "," + s.vehicle.getId() + "," + s.route + "," + s.cost);
            }
        } catch (IOException e) {
            System.out.println("Error guardando servicios: " + e.getMessage());
        }
    }
    
    /**
     * Guarda el grafo del mapa (aristas y pesos) en un archivo CSV.
     * Formato: Origen,Destino,Peso
     */
    public void saveMap(Graph graph, String file) {
        try (PrintWriter writer = new PrintWriter(file)) {
            var map = graph.getEdgeMap();
            for (var entry : map.entrySet()) {
                String origin = entry.getKey();
                for (Edge edge : entry.getValue()) {
                    writer.println(origin + "," + edge.getTo() + "," + edge.getWeight());
                }
            }
        } catch (IOException e) {
            System.out.println("Error guardando mapa: " + e.getMessage());
        }
    }
    
    /**
     * Carga el grafo del mapa desde un archivo CSV.
     * Evita duplicados bidireccionales (A-B y B-A se cuenta como uno).
     */
    public void loadMap(Graph graph, String file) {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            StringList added = new StringList();
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    String key = parts[0] + "-" + parts[1];
                    String inverseKey = parts[1] + "-" + parts[0];
                    if (!added.contains(key) && !added.contains(inverseKey)) {
                        graph.addEdge(parts[0], parts[1], Integer.parseInt(parts[2]));
                        added.add(key);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Error cargando mapa: " + e.getMessage());
        }
    }
    
    /**
     * Guarda todos los vehículos usando archivo por defecto (vehiculos.txt).
     * Método de conveniencia para operaciones estándar.
     */
    public void saveAll(Utils utils) {
        try (PrintWriter writer = new PrintWriter("vehiculos.txt")) {
            for (Vehicle v : utils.vehiculos.getAll()) {
                writer.println(v.getId() + "," + v.getCurrentZone() + "," + v.getServiceCount() + "," + v.isAvailable() + "," + v.getDriverName() + "," + v.getVehicleType());
            }
        } catch (IOException e) {
            System.out.println("Error guardando vehículos: " + e.getMessage());
        }
        System.out.println("Datos guardados exitosamente");
    }
    
    /**
     * Carga todos los vehículos desde archivo por defecto (vehiculos.txt).
     * Método de conveniencia para operaciones estándar.
     */
    public void loadAll(Utils utils) {
        VehicleList vehicles = loadVehicles("vehiculos.txt");
        for (Vehicle v : vehicles.getAll()) {
            utils.vehiculos.add(v);
        }
        System.out.println("Datos cargados exitosamente");
    }
    
    /**
     * Guarda el historial de eventos en un archivo de texto.
     */
    public void saveHistory(StringList eventHistory, String file) {
        try (PrintWriter writer = new PrintWriter(file)) {
            for (int i = 0; i < eventHistory.getSize(); i++) {
                writer.println(eventHistory.get(i));
            }
        } catch (IOException e) {
            System.out.println("Error guardando historial: " + e.getMessage());
        }
    }
    
    /**
     * Carga el historial de eventos desde un archivo de texto.
     */
    public StringList loadHistory(String file) {
        StringList list = new StringList();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                list.add(line);
            }
        } catch (IOException e) {
            System.out.println("Error cargando historial: " + e.getMessage());
        }
        return list;
    }
    
    /**
     * Carga todos los datos iniciales desde archivo de configuración.
     * Soporta secciones: VEHÍCULOS, MAPA, TARIFAS, SOLICITUDES
     */
    public void loadInitialData(Utils utils, String file) {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            String section = "";
            
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                
                // Ignorar líneas vacías
                if (line.isEmpty()) continue;
                
                // Detectar secciones
                if (line.startsWith("===")) {
                    section = line.replace("===", "").trim();
                    continue;
                }
                
                // Procesar según la sección
                if (section.contains("VEHÍCULOS")) {
                    String[] parts = line.split(",");
                    if (parts.length >= 4) {
                        String id = parts[0].trim();
                        String driverName = parts[1].trim();
                        String zone = parts[2].trim();
                        String vehicleType = parts[3].trim();
                        utils.vehiculos.add(new Vehicle(id, driverName, zone, vehicleType));
                    }
                }
                else if (section.contains("MAPA")) {
                    String[] parts = line.split(",");
                    if (parts.length >= 3) {
                        String origin = parts[0].trim();
                        String destination = parts[1].trim();
                        int weight = Integer.parseInt(parts[2].trim());
                        utils.mapa.addEdge(origin, destination, weight);
                    }
                }
                else if (section.contains("TARIFAS")) {
                    String[] parts = line.split(",");
                    if (parts.length >= 2) {
                        String category = parts[0].trim();
                        double price = Double.parseDouble(parts[1].trim());
                        utils.tarifas.add(category, price);
                    }
                }
                else if (section.contains("SOLICITUDES")) {
                    String[] parts = line.split(",");
                    if (parts.length >= 5) {
                        String id = parts[0].trim();
                        String client = parts[1].trim();
                        String origin = parts[2].trim();
                        String destination = parts[3].trim();
                        int category = Integer.parseInt(parts[4].trim());
                        Request request = new Request(id, origin, destination, client, category);
                        if (request.getClientCategory() == 3) {
                            utils.colaUrgente.enqueue(request, 4);
                            utils.historialEventos.push("EMERGENCIA: " + request.getClientName() + " de " + request.getOrigin() + " a " + request.getDestination());
                        } else {
                            utils.colaNormal.enqueue(request);
                            String categoryName = getCategoryName(category);
                            utils.historialEventos.push(categoryName.toUpperCase() + ": " + request.getClientName() + " de " + request.getOrigin() + " a " + request.getDestination());
                        }
                    }
                }
            }
            System.out.println("Datos iniciales cargados desde " + file);
        } catch (IOException e) {
            System.out.println("Error cargando datos iniciales: " + e.getMessage());
        }
    }
}